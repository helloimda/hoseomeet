class AppConfig {
  static const String baseUrl = 'http://172.28.192.1:8000/api/v1';
}
