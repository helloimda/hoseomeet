package com.company.hoseomeet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
